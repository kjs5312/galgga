package com.galgga.reserve.vo;

public class BeforeResVO {

	
	
	// ������ �ѱ� �뵵�� �� VO
	
	
	
	public int lod_id;
	public int unit_id;
	public String lod_name;
	public String unit_name;
	public String lod_category;
	public int M_id;
	public String unit_price;
	public String min_p;
	public String max_p;
	public String adult;
	public String child;
	
	
	public String lod_option1;
	public String lod_option1_price;
	public String lod_option1_info;

	public String lod_option2;
	public String lod_option2_price;
	public String lod_option2_info;

	public String lod_option3;
	public String lod_option3_price;
	public String lod_option3_info;

	public String lod_option4;
	public String lod_option4_price;
	public String lod_option4_info;

	public String lod_option5;
	public String lod_option5_price;
	public String lod_option5_info;

	public String lod_option6;
	public String lod_option6_price;
	public String lod_option6_info;
	public int getLod_id() {
		return lod_id;
	}
	public void setLod_id(int lod_id) {
		this.lod_id = lod_id;
	}
	public int getUnit_id() {
		return unit_id;
	}
	public void setUnit_id(int unit_id) {
		this.unit_id = unit_id;
	}
	public String getLod_name() {
		return lod_name;
	}
	public void setLod_name(String lod_name) {
		this.lod_name = lod_name;
	}
	public String getUnit_name() {
		return unit_name;
	}
	public void setUnit_name(String unit_name) {
		this.unit_name = unit_name;
	}
	public String getLod_category() {
		return lod_category;
	}
	public void setLod_category(String lod_category) {
		this.lod_category = lod_category;
	}

	public int getM_id() {
		return M_id;
	}
	public void setM_id(int m_id) {
		M_id = m_id;
	}
	public String getUnit_price() {
		return unit_price;
	}
	public void setUnit_price(String unit_price) {
		this.unit_price = unit_price;
	}
	public String getMin_p() {
		return min_p;
	}
	public void setMin_p(String min_p) {
		this.min_p = min_p;
	}
	public String getMax_p() {
		return max_p;
	}
	public void setMax_p(String max_p) {
		this.max_p = max_p;
	}
	public String getLod_option1() {
		return lod_option1;
	}
	public void setLod_option1(String lod_option1) {
		this.lod_option1 = lod_option1;
	}
	public String getLod_option1_price() {
		return lod_option1_price;
	}
	public void setLod_option1_price(String lod_option1_price) {
		this.lod_option1_price = lod_option1_price;
	}
	public String getLod_option1_info() {
		return lod_option1_info;
	}
	public void setLod_option1_info(String lod_option1_info) {
		this.lod_option1_info = lod_option1_info;
	}
	public String getLod_option2() {
		return lod_option2;
	}
	public void setLod_option2(String lod_option2) {
		this.lod_option2 = lod_option2;
	}
	public String getLod_option2_price() {
		return lod_option2_price;
	}
	public void setLod_option2_price(String lod_option2_price) {
		this.lod_option2_price = lod_option2_price;
	}
	public String getLod_option2_info() {
		return lod_option2_info;
	}
	public void setLod_option2_info(String lod_option2_info) {
		this.lod_option2_info = lod_option2_info;
	}
	public String getLod_option3() {
		return lod_option3;
	}
	public void setLod_option3(String lod_option3) {
		this.lod_option3 = lod_option3;
	}
	public String getLod_option3_price() {
		return lod_option3_price;
	}
	public void setLod_option3_price(String lod_option3_price) {
		this.lod_option3_price = lod_option3_price;
	}
	public String getLod_option3_info() {
		return lod_option3_info;
	}
	public void setLod_option3_info(String lod_option3_info) {
		this.lod_option3_info = lod_option3_info;
	}
	public String getLod_option4() {
		return lod_option4;
	}
	public void setLod_option4(String lod_option4) {
		this.lod_option4 = lod_option4;
	}
	public String getLod_option4_price() {
		return lod_option4_price;
	}
	public void setLod_option4_price(String lod_option4_price) {
		this.lod_option4_price = lod_option4_price;
	}
	public String getLod_option4_info() {
		return lod_option4_info;
	}
	public void setLod_option4_info(String lod_option4_info) {
		this.lod_option4_info = lod_option4_info;
	}
	public String getLod_option5() {
		return lod_option5;
	}
	public void setLod_option5(String lod_option5) {
		this.lod_option5 = lod_option5;
	}
	public String getLod_option5_price() {
		return lod_option5_price;
	}
	public void setLod_option5_price(String lod_option5_price) {
		this.lod_option5_price = lod_option5_price;
	}
	public String getLod_option5_info() {
		return lod_option5_info;
	}
	public void setLod_option5_info(String lod_option5_info) {
		this.lod_option5_info = lod_option5_info;
	}
	public String getLod_option6() {
		return lod_option6;
	}
	public void setLod_option6(String lod_option6) {
		this.lod_option6 = lod_option6;
	}
	public String getLod_option6_price() {
		return lod_option6_price;
	}
	public void setLod_option6_price(String lod_option6_price) {
		this.lod_option6_price = lod_option6_price;
	}
	public String getLod_option6_info() {
		return lod_option6_info;
	}
	public void setLod_option6_info(String lod_option6_info) {
		this.lod_option6_info = lod_option6_info;
	}
	public String getAdult() {
		return adult;
	}
	public void setAdult(String adult) {
		this.adult = adult;
	}
	public String getChild() {
		return child;
	}
	public void setChild(String child) {
		this.child = child;
	}
		
	
	
	
	
	
	
	
	
}
