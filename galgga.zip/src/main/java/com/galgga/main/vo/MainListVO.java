package com.galgga.main.vo;

public class MainListVO {

	public String lod_name;
	public int lod_id;
	public String lod_category;
	public String lod_valuation;
	public String lod_imgName;
	public String lod_price;
	public String lod_address;
	
	public String getLod_name() {
		return lod_name;
	}
	public void setLod_name(String lod_name) {
		this.lod_name = lod_name;
	}
	public int getLod_id() {
		return lod_id;
	}
	public void setLod_id(int lod_id) {
		this.lod_id = lod_id;
	}
	public String getLod_category() {
		return lod_category;
	}
	public void setLod_category(String lod_category) {
		this.lod_category = lod_category;
	}
	public String getLod_valuation() {
		return lod_valuation;
	}
	public void setLod_valuation(String lod_valuation) {
		this.lod_valuation = lod_valuation;
	}
	public String getLod_imgName() {
		return lod_imgName;
	}
	public void setLod_imgName(String lod_imgName) {
		this.lod_imgName = lod_imgName;
	}
	public String getLod_price() {
		return lod_price;
	}
	public void setLod_price(String lod_price) {
		this.lod_price = lod_price;
	}
	public String getLod_address() {
		return lod_address;
	}
	public void setLod_address(String lod_address) {
		this.lod_address = lod_address;
	}

	
	
	
	
	
}
