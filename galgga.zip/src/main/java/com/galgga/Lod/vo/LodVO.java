package com.galgga.Lod.vo;

import java.util.Date;

public class LodVO {
	public int lod_id;
	public String lod_name;
	public String post_num;
	public String lod_address;
	public String lod_category;
	public String lod_valuation;
	public String lod_info;
	public Date add_date;
	public String state;
	public int B_id;
	
	public String lod_option1;
	public String lod_option1_price;
	public String lod_option1_info;

	public String lod_option2;
	public String lod_option2_price;
	public String lod_option2_info;

	public String lod_option3;
	public String lod_option3_price;
	public String lod_option3_info;

	public String lod_option4;
	public String lod_option4_price;
	public String lod_option4_info;

	public String lod_option5;
	public String lod_option5_price;
	public String lod_option5_info;

	public String lod_option6;
	public String lod_option6_price;
	public String lod_option6_info;
	
	
	public int getLod_id() {
		return lod_id;
	}
	public void setLod_id(int lod_id) {
		this.lod_id = lod_id;
	}
	public String getLod_name() {
		return lod_name;
	}
	public void setLod_name(String lod_name) {
		this.lod_name = lod_name;
	}
	public String getPost_num() {
		return post_num;
	}
	public void setPost_num(String post_num) {
		this.post_num = post_num;
	}
	public String getLod_address() {
		return lod_address;
	}
	public void setLod_address(String lod_address) {
		this.lod_address = lod_address;
	}
	public String getLod_category() {
		return lod_category;
	}
	public void setLod_category(String lod_category) {
		this.lod_category = lod_category;
	}
	public String getLod_valuation() {
		return lod_valuation;
	}
	public void setLod_valuation(String lod_valuation) {
		this.lod_valuation = lod_valuation;
	}
	public String getLod_info() {
		return lod_info;
	}
	public void setLod_info(String lod_info) {
		this.lod_info = lod_info;
	}
	public Date getAdd_date() {
		return add_date;
	}
	public void setAdd_date(Date add_date) {
		this.add_date = add_date;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getB_id() {
		return B_id;
	}
	public void setB_id(int b_id) {
		B_id = b_id;
	}
	public String getLod_option1() {
		return lod_option1;
	}
	public void setLod_option1(String lod_option1) {
		this.lod_option1 = lod_option1;
	}
	public String getLod_option1_price() {
		return lod_option1_price;
	}
	public void setLod_option1_price(String lod_option1_price) {
		this.lod_option1_price = lod_option1_price;
	}
	public String getlod_option1_info() {
		return lod_option1_info;
	}
	public void setlod_option1_info(String lod_option1_info) {
		this.lod_option1_info = lod_option1_info;
	}
	public String getLod_option2() {
		return lod_option2;
	}
	public void setLod_option2(String lod_option2) {
		this.lod_option2 = lod_option2;
	}
	public String getLod_option2_price() {
		return lod_option2_price;
	}
	public void setLod_option2_price(String lod_option2_price) {
		this.lod_option2_price = lod_option2_price;
	}
	public String getlod_option2_info() {
		return lod_option2_info;
	}
	public void setlod_option2_info(String lod_option2_info) {
		this.lod_option2_info = lod_option2_info;
	}
	public String getLod_option3() {
		return lod_option3;
	}
	public void setLod_option3(String lod_option3) {
		this.lod_option3 = lod_option3;
	}
	public String getLod_option3_price() {
		return lod_option3_price;
	}
	public void setLod_option3_price(String lod_option3_price) {
		this.lod_option3_price = lod_option3_price;
	}
	public String getlod_option3_info() {
		return lod_option3_info;
	}
	public void setlod_option3_info(String lod_option3_info) {
		this.lod_option3_info = lod_option3_info;
	}
	public String getLod_option4() {
		return lod_option4;
	}
	public void setLod_option4(String lod_option4) {
		this.lod_option4 = lod_option4;
	}
	public String getLod_option4_price() {
		return lod_option4_price;
	}
	public void setLod_option4_price(String lod_option4_price) {
		this.lod_option4_price = lod_option4_price;
	}
	public String getlod_option4_info() {
		return lod_option4_info;
	}
	public void setlod_option4_info(String lod_option4_info) {
		this.lod_option4_info = lod_option4_info;
	}
	public String getLod_option5() {
		return lod_option5;
	}
	public void setLod_option5(String lod_option5) {
		this.lod_option5 = lod_option5;
	}
	public String getLod_option5_price() {
		return lod_option5_price;
	}
	public void setLod_option5_price(String lod_option5_price) {
		this.lod_option5_price = lod_option5_price;
	}
	public String getlod_option5_info() {
		return lod_option5_info;
	}
	public void setlod_option5_info(String lod_option5_info) {
		this.lod_option5_info = lod_option5_info;
	}
	public String getLod_option6() {
		return lod_option6;
	}
	public void setLod_option6(String lod_option6) {
		this.lod_option6 = lod_option6;
	}
	public String getLod_option6_price() {
		return lod_option6_price;
	}
	public void setLod_option6_price(String lod_option6_price) {
		this.lod_option6_price = lod_option6_price;
	}
	public String getlod_option6_info() {
		return lod_option6_info;
	}
	public void setlod_option6_info(String lod_option6_info) {
		this.lod_option6_info = lod_option6_info;
	}
	
	
	
	
	
	
	
	
	
		
	
	
	
	
}
